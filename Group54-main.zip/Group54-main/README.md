# Group54 - Small Business Search

Description:
Create an app that allows users to see small businesses within a certain radius that meet the tags they are looking for. Allows people to see what small businesses exist near them given certain parameters. 
Small businesses can create a profile to be seen on the app and edit their location, tags, logo, and short description/products offered.

People: 

	Backend: Rohan Rao, Blake Budd
	
	Frontend: Wavid Bowman, Ivan Saldarriaga

How: Use Leaflet for map services. Go Library  - database.sql 
